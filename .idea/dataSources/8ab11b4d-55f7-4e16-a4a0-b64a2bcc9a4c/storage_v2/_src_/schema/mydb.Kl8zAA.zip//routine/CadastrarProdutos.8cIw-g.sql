create
    definer = root@`%` procedure CadastrarProdutos(IN NomeProduto varchar(100), IN Descricao text,
                                                   IN QtdEstoque int unsigned, IN PrecoDeCompra decimal(10, 2),
                                                   IN PrecoDeVenda decimal(10, 2), IN CategoriaId int)
BEGIN
    -- Inserção do produto
    INSERT INTO Produto (NomeProduto, Descricao, QtdEstoque, PrecoDeCompra, PrecoDeVenda)
    VALUES (NomeProduto, Descricao, QtdEstoque, PrecoDeCompra, PrecoDeVenda);

    -- Captura do ID do produto inserido
    SET @ProdutoId = LAST_INSERT_ID();

    -- Inserção na tabela de associação Produto_has_Categoria
    INSERT INTO Produto_has_Categoria (Produto_IdProduto, Categoria_idCategoria)
    VALUES (@ProdutoId, CategoriaId);
END;

