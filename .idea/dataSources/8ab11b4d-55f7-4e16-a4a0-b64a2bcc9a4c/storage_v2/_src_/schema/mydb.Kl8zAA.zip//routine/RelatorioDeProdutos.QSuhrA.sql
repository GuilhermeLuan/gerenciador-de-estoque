create
    definer = root@`%` procedure RelatorioDeProdutos()
BEGIN
    SELECT * FROM Produto;
END;

