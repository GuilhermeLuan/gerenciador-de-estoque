create
    definer = root@`%` procedure CadastrarCategoria(IN NomeCategoria varchar(100), IN Descricao text, OUT IdCategoria int)
BEGIN
    INSERT INTO Categoria (NomeCategoria, Descricao)
    VALUES (NomeCategoria, Descricao);

    -- Captura o último ID inserido
    SET IdCategoria = LAST_INSERT_ID();
END;

