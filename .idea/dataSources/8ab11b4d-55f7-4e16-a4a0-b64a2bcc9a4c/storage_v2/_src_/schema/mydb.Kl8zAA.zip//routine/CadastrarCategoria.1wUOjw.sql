create
    definer = root@`%` procedure CadastrarCategoria(IN NomeCategoria varchar(100), IN Descricao text)
BEGIN
    INSERT INTO Categoria (NomeCategoria, Descricao)
    VALUES (NomeCategoria, Descricao);
END;

