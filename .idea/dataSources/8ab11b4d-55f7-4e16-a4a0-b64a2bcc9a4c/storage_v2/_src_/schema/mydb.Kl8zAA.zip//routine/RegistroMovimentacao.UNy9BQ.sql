create
    definer = root@`%` procedure RegistroMovimentacao(IN p_produto_id int,
                                                      IN p_tipo_movimentacao enum ('ENTRADA', 'SAIDA'),
                                                      IN p_quantidade int)
BEGIN
    IF p_tipo_movimentacao = 'ENTRADA' THEN
        UPDATE Produto
        SET QtdEstoque = QtdEstoque + p_quantidade
        WHERE IdProduto = p_produto_id;

        INSERT INTO MovimentacaoEstoque (produto_id, tipo_movimentacao, quantidade)
        VALUES (p_produto_id, 'ENTRADA', p_quantidade);

    ELSEIF p_tipo_movimentacao = 'SAIDA' THEN
        UPDATE Produto
        SET QtdEstoque = QtdEstoque - p_quantidade
        WHERE IdProduto = p_produto_id;

        INSERT INTO MovimentacaoEstoque (produto_id, tipo_movimentacao, quantidade)
        VALUES (p_produto_id, 'SAIDA', p_quantidade);
    END IF;
END;

