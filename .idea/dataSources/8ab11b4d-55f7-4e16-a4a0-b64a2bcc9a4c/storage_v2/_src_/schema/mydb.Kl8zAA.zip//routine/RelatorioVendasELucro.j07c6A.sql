create
    definer = root@`%` procedure RelatorioVendasELucro()
BEGIN
    -- Verificar se há registros de saída na tabela MovimentacaoEstoque
    IF (SELECT COUNT(*) FROM MovimentacaoEstoque WHERE tipo_movimentacao = 'SAIDA') = 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Não há movimentações de saída registradas.';
    ELSE
        SELECT p.IdProduto                                                       AS ProdutoID,
               p.NomeProduto                                                     AS Nome,
               IFNULL(SUM(m.quantidade), 0)                                      AS QuantidadeVendida,
               IFNULL(SUM(m.quantidade * p.PrecoDeVenda), 0)                     AS TotalVendas,
               IFNULL(SUM(m.quantidade * p.PrecoDeCompra), 0)                    AS CustoTotal,
               IFNULL(SUM(m.quantidade * (p.PrecoDeVenda - p.PrecoDeCompra)), 0) AS LucroTotal
        FROM Produto p
                 LEFT JOIN
             MovimentacaoEstoque m
             ON
                 p.IdProduto = m.produto_id
        WHERE m.tipo_movimentacao = 'SAIDA' -- Apenas registros com saída de produtos
        GROUP BY p.IdProduto, p.NomeProduto;
    END IF;
END;

