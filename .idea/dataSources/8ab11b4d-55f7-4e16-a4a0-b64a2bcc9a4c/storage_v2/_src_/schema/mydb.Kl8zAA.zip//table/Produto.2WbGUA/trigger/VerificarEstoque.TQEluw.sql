create definer = root@`%` trigger VerificarEstoque
    after update
    on Produto
    for each row
BEGIN
    IF NEW.QtdEstoque < 10 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Esse Produto está com o estoque abaixo do mínimo.';
    END IF;
END;

